from setuptools import setup, find_packages

setup(
    name="ccts",
    version="1.0.0",
    description="Carbon Credit Trading Scheme Simulation for India",
    long_description=open("README.md", "r", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Ankit Sharma",
    author_email="your.email@example.com",
    url="https://github.com/ankitsharmaMCET/ccts",
    packages=find_packages(include=["ccts", "ccts.*"]),
    python_requires=">=3.8",
    install_requires=[
        "mesa>=2.3.2",
        "numpy>=1.20.0",
        "pandas>=1.4.0",
        "scipy>=1.7.0",
        "matplotlib>=3.5.0",
        "xlsxwriter>=3.0.0",
        "openpyxl"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    entry_points={
        "console_scripts": [
            "ccts=ccts.run_simulation:main",
        ],
    },
)
